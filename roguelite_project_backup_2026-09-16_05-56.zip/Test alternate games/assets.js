/**
 * assets.js - Процедурный генератор пиксель-арта
 * Генерирует высокодетализированные спрайты и тайлы на offscreen-холстах.
 * Никаких внешних PNG - чистый код и пиксельная палитра в духе Stardew Valley!
 */

const PixelAssets = {
  sprites: {},

  // Палитра Stardew / Earthy retro
  palette: {
    // Трава и листва
    grassDark: '#2c5324',
    grassMid: '#447c32',
    grassLight: '#67a840',
    grassBright: '#8fd34f',
    grassFlowerYellow: '#f4d03f',
    grassFlowerRed: '#e74c3c',
    grassFlowerBlue: '#5dade2',

    // Вода
    waterDeep: '#1f4870',
    waterMid: '#2d689e',
    waterLight: '#4d8fc8',
    waterFoam: '#e4f3fa',

    // Земля и тропинки
    dirtDark: '#432918',
    dirtMid: '#6d4223',
    dirtLight: '#996335',
    dirtPebble: '#ba8d61',

    // Дерево и доски
    woodDark: '#351d11',
    woodMid: '#5c351f',
    woodLight: '#8a532d',
    woodHighlight: '#b37542',

    // Камень и крыша
    stoneDark: '#2e313b',
    stoneMid: '#484d5c',
    stoneLight: '#6e768d',
    roofRed: '#9e3427',
    roofRedLight: '#c24b3b',

    // Теплый свет и огонь
    goldBright: '#ffd13b',
    fireOrange: '#ff7714',
    fireYellow: '#fff275',
    fireRed: '#c72c1e',
    lampGlow: '#ffeaa7'
  },

  init() {
    this.createWaterTiles();
    this.createTerrainTiles();
    this.createCrops();
    this.createTrees();
    this.createCabin();
    this.createCampfire();
    this.createCharacter();
    this.createDecorations();
  },

  // Создает вспомогательный холст нужного размера
  makeCanvas(w, h) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    return { canvas: c, ctx };
  },

  // Заливка одного пикселя
  px(ctx, x, y, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, 1, 1);
  },

  // Прямоугольник из пикселей
  rect(ctx, x, y, w, h, color) {
    ctx.fillStyle = color;
    ctx.fillRect(x, y, w, h);
  },

  /* ------------------- ВОДА И БЕРЕГ ------------------- */
  createWaterTiles() {
    this.sprites.waterFrames = [];
    for (let f = 0; f < 4; f++) {
      const { canvas, ctx } = this.makeCanvas(16, 16);
      this.rect(ctx, 0, 0, 16, 16, this.palette.waterMid);

      // Глубинные волны
      for (let y = 0; y < 16; y += 4) {
        const offset = ((y / 4) % 2 === 0 ? f * 2 : (4 - f) * 2) % 16;
        this.px(ctx, (2 + offset) % 16, y, this.palette.waterDeep);
        this.px(ctx, (3 + offset) % 16, y, this.palette.waterDeep);
        this.px(ctx, (4 + offset) % 16, y, this.palette.waterLight);
      }

      // Блики на воде
      const sparkX = (f * 5 + 3) % 15;
      const sparkY = ((f * 7) + 2) % 15;
      this.px(ctx, sparkX, sparkY, this.palette.waterFoam);
      this.px(ctx, (sparkX + 7) % 15, (sparkY + 6) % 15, this.palette.waterLight);

      this.sprites.waterFrames.push(canvas);
    }
  },

  /* ------------------- ТРАВА И ТРОПИНКИ ------------------- */
  createTerrainTiles() {
    // Базовая трава с микро-текстурой
    const grass = this.makeCanvas(16, 16);
    this.rect(grass.ctx, 0, 0, 16, 16, this.palette.grassMid);
    // Пиксели травинок
    const grassDetails = [
      [2, 3], [3, 2], [7, 8], [8, 7], [13, 4], [14, 3], [5, 12], [6, 13], [11, 11]
    ];
    grassDetails.forEach(([x, y]) => {
      this.px(grass.ctx, x, y, this.palette.grassLight);
      this.px(grass.ctx, x, y + 1, this.palette.grassDark);
    });
    this.sprites.grass = grass.canvas;

    // Трава с цветами
    const grassFlowers = this.makeCanvas(16, 16);
    grassFlowers.ctx.drawImage(this.sprites.grass, 0, 0);
    // Желтый цветок
    this.px(grassFlowers.ctx, 4, 5, this.palette.grassFlowerYellow);
    this.px(grassFlowers.ctx, 5, 5, this.palette.grassFlowerYellow);
    this.px(grassFlowers.ctx, 4, 6, this.palette.grassFlowerYellow);
    this.px(grassFlowers.ctx, 5, 6, '#e67e22');
    // Красный цветок
    this.px(grassFlowers.ctx, 11, 9, this.palette.grassFlowerRed);
    this.px(grassFlowers.ctx, 12, 9, this.palette.grassFlowerRed);
    this.px(grassFlowers.ctx, 11, 10, '#ffffff');
    this.sprites.grassFlowers = grassFlowers.canvas;

    // Земляная тропинка
    const dirt = this.makeCanvas(16, 16);
    this.rect(dirt.ctx, 0, 0, 16, 16, this.palette.dirtMid);
    // Камушки и перепады высоты
    const dirtDetails = [[1, 2], [6, 7], [12, 3], [9, 13], [3, 11], [14, 9]];
    dirtDetails.forEach(([x, y]) => {
      this.px(dirt.ctx, x, y, this.palette.dirtLight);
      this.px(dirt.ctx, x + 1, y, this.palette.dirtPebble);
      this.px(dirt.ctx, x, y + 1, this.palette.dirtDark);
    });
    this.sprites.dirt = dirt.canvas;

    // Вспаханная грядка
    const tilledSoil = this.makeCanvas(16, 16);
    this.rect(tilledSoil.ctx, 0, 0, 16, 16, '#3a2012');
    for (let y = 1; y < 15; y += 4) {
      this.rect(tilledSoil.ctx, 1, y, 14, 2, '#4d2a17');
      this.rect(tilledSoil.ctx, 1, y + 2, 14, 1, '#2c180e');
    }
    this.sprites.tilledSoil = tilledSoil.canvas;

    // Деревянный настил моста
    const bridge = this.makeCanvas(16, 16);
    this.rect(bridge.ctx, 0, 0, 16, 16, this.palette.woodMid);
    for (let y = 0; y < 16; y += 4) {
      this.rect(bridge.ctx, 0, y, 16, 1, this.palette.woodDark);
      this.rect(bridge.ctx, 0, y + 1, 16, 1, this.palette.woodHighlight);
      this.px(bridge.ctx, 2, y + 2, this.palette.woodDark);
      this.px(bridge.ctx, 13, y + 2, this.palette.woodDark);
    }
    this.sprites.bridge = bridge.canvas;
  },

  /* ------------------- КУЛЬТУРЫ / РАСТЕНИЯ НА ГРЯДКЕ ------------------- */
  createCrops() {
    // 1. Росток
    const sprout = this.makeCanvas(16, 16);
    this.px(sprout.ctx, 8, 11, this.palette.grassBright);
    this.px(sprout.ctx, 7, 10, this.palette.grassLight);
    this.px(sprout.ctx, 9, 10, this.palette.grassLight);
    this.sprites.cropSprout = sprout.canvas;

    // 2. Морковь / Пастернак созревший
    const carrot = this.makeCanvas(16, 16);
    // Ботва
    this.rect(carrot.ctx, 7, 5, 2, 4, this.palette.grassLight);
    this.px(carrot.ctx, 6, 6, this.palette.grassBright);
    this.px(carrot.ctx, 9, 6, this.palette.grassBright);
    // Оранжевый плод в земле
    this.rect(carrot.ctx, 7, 9, 2, 4, '#e67e22');
    this.px(carrot.ctx, 7, 9, '#f39c12');
    this.px(carrot.ctx, 8, 12, '#d35400');
    this.sprites.cropCarrot = carrot.canvas;

    // 3. Клубника
    const strawberry = this.makeCanvas(16, 16);
    // Листики кустика
    this.rect(strawberry.ctx, 5, 8, 6, 4, this.palette.grassLight);
    this.px(strawberry.ctx, 4, 9, this.palette.grassMid);
    this.px(strawberry.ctx, 11, 9, this.palette.grassMid);
    // Ягодки
    this.px(strawberry.ctx, 6, 10, '#e74c3c');
    this.px(strawberry.ctx, 7, 11, '#c0392b');
    this.px(strawberry.ctx, 9, 10, '#e74c3c');
    this.px(strawberry.ctx, 6, 10, '#f1948a');
    this.sprites.cropStrawberry = strawberry.canvas;
  },

  /* ------------------- ДЕРЕВЬЯ (ДУБ И ЕЛЬ) ------------------- */
  createTrees() {
    // Большой пышный Дуб (32x48)
    const oak = this.makeCanvas(32, 48);
    const oCtx = oak.ctx;

    // Тень под деревом
    oCtx.fillStyle = 'rgba(15, 25, 12, 0.45)';
    oCtx.beginPath();
    oCtx.ellipse(16, 44, 12, 4, 0, 0, Math.PI * 2);
    oCtx.fill();

    // Ствол
    this.rect(oCtx, 13, 30, 6, 14, this.palette.woodDark);
    this.rect(oCtx, 14, 30, 4, 13, this.palette.woodMid);
    this.rect(oCtx, 15, 30, 2, 11, this.palette.woodLight);
    // Корни
    this.px(oCtx, 12, 43, this.palette.woodDark);
    this.px(oCtx, 19, 43, this.palette.woodDark);

    // Крона дуба (многослойная круглая шапка с объемом)
    const drawLeafCluster = (cx, cy, r, baseColor, lightColor, darkColor) => {
      oCtx.fillStyle = darkColor;
      oCtx.beginPath();
      oCtx.arc(cx, cy + 2, r, 0, Math.PI * 2);
      oCtx.fill();

      oCtx.fillStyle = baseColor;
      oCtx.beginPath();
      oCtx.arc(cx, cy, r - 1, 0, Math.PI * 2);
      oCtx.fill();

      oCtx.fillStyle = lightColor;
      oCtx.beginPath();
      oCtx.arc(cx - 2, cy - 2, r * 0.55, 0, Math.PI * 2);
      oCtx.fill();
    };

    // Нижние темные массы кроны
    drawLeafCluster(10, 24, 8, this.palette.grassDark, this.palette.grassMid, '#1a3315');
    drawLeafCluster(22, 24, 8, this.palette.grassDark, this.palette.grassMid, '#1a3315');
    // Центральная крона
    drawLeafCluster(8, 16, 9, this.palette.grassMid, this.palette.grassLight, this.palette.grassDark);
    drawLeafCluster(23, 16, 9, this.palette.grassMid, this.palette.grassLight, this.palette.grassDark);
    // Верхушка
    drawLeafCluster(16, 11, 10, this.palette.grassMid, this.palette.grassLight, this.palette.grassDark);
    // Яркие блики солнца на верхних листьях
    this.px(oCtx, 14, 5, this.palette.grassBright);
    this.px(oCtx, 15, 5, this.palette.grassBright);
    this.px(oCtx, 15, 6, this.palette.grassBright);
    this.px(oCtx, 9, 11, this.palette.grassBright);

    this.sprites.oakTree = oak.canvas;

    // Ель (32x48)
    const pine = this.makeCanvas(32, 48);
    const pCtx = pine.ctx;

    // Тень
    pCtx.fillStyle = 'rgba(15, 25, 12, 0.45)';
    pCtx.beginPath();
    pCtx.ellipse(16, 45, 10, 3, 0, 0, Math.PI * 2);
    pCtx.fill();

    // Ствол
    this.rect(pCtx, 14, 38, 4, 7, this.palette.woodDark);

    // Ярусы хвои (треугольники снизу вверх)
    const drawPineTier = (y, w, h) => {
      for (let row = 0; row < h; row++) {
        const curW = Math.floor((row / h) * w);
        const startX = 16 - curW;
        const totalW = curW * 2;
        this.rect(pCtx, startX, y + row, totalW, 1, '#1b3a24');
        this.rect(pCtx, startX + 1, y + row, totalW - 2, 1, '#2a5534');
        this.rect(pCtx, startX + 2, y + row, Math.floor(curW * 0.7), 1, '#3d784a');
      }
    };

    drawPineTier(26, 14, 13); // Нижний ярус
    drawPineTier(17, 11, 11); // Средний
    drawPineTier(8, 8, 10);   // Верхний
    drawPineTier(3, 4, 6);    // Верхушка
    this.px(pCtx, 16, 2, '#4d945c'); // Кончик

    this.sprites.pineTree = pine.canvas;
  },

  /* ------------------- УЮТНЫЙ ДОМИК ФЕРМЕРА (64x64) ------------------- */
  createCabin() {
    const { canvas, ctx } = this.makeCanvas(64, 64);

    // Тень под домом
    ctx.fillStyle = 'rgba(10, 15, 12, 0.5)';
    ctx.fillRect(4, 58, 56, 4);

    // Каменный фундамент
    this.rect(ctx, 6, 52, 52, 8, this.palette.stoneMid);
    for (let x = 6; x < 58; x += 8) {
      this.rect(ctx, x, 52, 1, 8, this.palette.stoneDark);
    }
    this.rect(ctx, 6, 59, 52, 1, this.palette.stoneDark);

    // Деревянные бревенчатые стены
    this.rect(ctx, 8, 28, 48, 24, this.palette.woodMid);
    for (let y = 28; y < 52; y += 4) {
      this.rect(ctx, 8, y, 48, 1, this.palette.woodDark);
      this.rect(ctx, 8, y + 1, 48, 1, this.palette.woodHighlight);
    }
    // Угловые вертикальные балки
    this.rect(ctx, 8, 28, 4, 24, this.palette.woodDark);
    this.rect(ctx, 52, 28, 4, 24, this.palette.woodDark);

    // Черепичная треугольная крыша
    for (let row = 0; row < 18; row++) {
      const w = 62 - row * 2.8;
      const x = (64 - w) / 2;
      this.rect(ctx, Math.floor(x), 10 + row, Math.floor(w), 1, this.palette.roofRed);
      // Срез черепицы
      if (row % 3 === 0) {
        this.rect(ctx, Math.floor(x), 10 + row, Math.floor(w), 1, this.palette.roofRedLight);
      }
    }
    // Конёк крыши
    this.rect(ctx, 22, 9, 20, 2, '#661c14');

    // Каменная труба с дымоходом
    this.rect(ctx, 42, 4, 8, 14, this.palette.stoneMid);
    this.rect(ctx, 41, 3, 10, 3, this.palette.stoneDark);
    this.rect(ctx, 43, 3, 6, 1, '#1b1b22');

    // Дверь
    this.rect(ctx, 27, 36, 10, 16, this.palette.woodDark);
    this.rect(ctx, 28, 37, 8, 15, '#784323');
    this.px(ctx, 35, 44, this.palette.goldBright); // Латунная ручка двери

    // Окно с теплым стеклом
    this.rect(ctx, 13, 34, 10, 10, this.palette.woodDark);
    this.rect(ctx, 14, 35, 8, 8, this.palette.lampGlow);
    // Крестовина рамы
    this.rect(ctx, 17, 35, 1, 8, this.palette.woodDark);
    this.rect(ctx, 14, 38, 8, 1, this.palette.woodDark);
    // Занавесочки
    this.rect(ctx, 14, 35, 2, 4, '#e74c3c');
    this.rect(ctx, 20, 35, 2, 4, '#e74c3c');

    this.sprites.cabin = canvas;
  },

  /* ------------------- АНИМИРОВАННЫЙ КОСТЕР (16x16) ------------------- */
  createCampfire() {
    this.sprites.campfireFrames = [];
    for (let f = 0; f < 4; f++) {
      const { canvas, ctx } = this.makeCanvas(16, 16);

      // Каменное кольцо в основании
      this.rect(ctx, 3, 11, 10, 3, this.palette.stoneMid);
      this.px(ctx, 4, 12, this.palette.stoneDark);
      this.px(ctx, 11, 12, this.palette.stoneDark);

      // Угли и обгоревшие бревнышки
      this.rect(ctx, 5, 11, 6, 2, '#2b1408');
      this.px(ctx, 6, 12, this.palette.fireRed);
      this.px(ctx, 9, 12, this.palette.fireRed);

      // Пламя с динамической сменой высоты и формы
      const flameH = 6 + (f % 2 === 0 ? 1 : -1);
      const shiftX = (f === 1 ? -1 : (f === 2 ? 1 : 0));

      // Языки пламени (красный, оранжевый, ярко-желтый центр)
      this.rect(ctx, 6 + shiftX, 11 - flameH, 4, flameH, this.palette.fireRed);
      this.rect(ctx, 7 + shiftX, 12 - flameH, 2, flameH - 1, this.palette.fireOrange);
      this.rect(ctx, 7, 12 - Math.floor(flameH * 0.7), 2, Math.floor(flameH * 0.6), this.palette.fireYellow);

      // Искорка в воздухе
      if (f === 0) this.px(ctx, 6, 3, this.palette.fireYellow);
      if (f === 2) this.px(ctx, 9, 2, this.palette.fireOrange);

      this.sprites.campfireFrames.push(canvas);
    }
  },

  /* ------------------- ПЕРСОНАЖ / ФЕРМЕР С АНИМАЦИЕЙ (16x24) ------------------- */
  createCharacter() {
    // Направления: 0: Вниз, 1: Вверх, 2: Влево, 3: Вправо
    // Каждое направление имеет 4 кадра шага (idle, step1, idle, step2)
    this.sprites.hero = {
      down: [],
      up: [],
      left: [],
      right: []
    };

    const skinColor = '#ffcc99';
    const skinDark = '#e5a36f';
    const hatStraw = '#f5c542';
    const hatBand = '#c0392b';
    const shirtRed = '#c0392b';
    const overallsBlue = '#2980b9';
    const overallsDark = '#1c5980';
    const bootsBrown = '#4a2810';

    for (let f = 0; f < 4; f++) {
      // Кадр анимации ходьбы (смещение ног)
      const legOffset1 = (f === 1 ? -1 : 0);
      const legOffset2 = (f === 3 ? 1 : 0);
      const bobY = (f === 1 || f === 3) ? 1 : 0;

      // 1. Вниз (Down)
      {
        const { canvas, ctx } = this.makeCanvas(16, 24);
        // Тень
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(8, 22, 5, 2, 0, 0, Math.PI*2);
        ctx.fill();

        // Соломенная шляпа
        this.rect(ctx, 3, 2 + bobY, 10, 3, hatStraw);
        this.rect(ctx, 5, 0 + bobY, 6, 3, hatStraw);
        this.rect(ctx, 5, 2 + bobY, 6, 1, hatBand);

        // Лицо
        this.rect(ctx, 5, 5 + bobY, 6, 4, skinColor);
        this.px(ctx, 6, 6 + bobY, '#2c3e50'); // Левый глаз
        this.px(ctx, 9, 6 + bobY, '#2c3e50'); // Правый глаз
        this.px(ctx, 7, 7 + bobY, skinDark);  // Нос

        // Рубашка и комбинезон
        this.rect(ctx, 4, 9 + bobY, 8, 6, overallsBlue);
        this.rect(ctx, 6, 9 + bobY, 4, 2, shirtRed); // Воротник
        this.rect(ctx, 5, 9 + bobY, 1, 5, overallsDark); // Лямка
        this.rect(ctx, 10, 9 + bobY, 1, 5, overallsDark); // Лямка

        // Руки
        this.rect(ctx, 3, 10 + bobY, 1, 4, skinColor);
        this.rect(ctx, 12, 10 + bobY, 1, 4, skinColor);

        // Ноги / Штаны
        this.rect(ctx, 5, 15, 2, 4 + legOffset1, overallsDark);
        this.rect(ctx, 9, 15, 2, 4 + legOffset2, overallsDark);

        // Сапоги
        this.rect(ctx, 5, 19 + legOffset1, 2, 2, bootsBrown);
        this.rect(ctx, 9, 19 + legOffset2, 2, 2, bootsBrown);

        this.sprites.hero.down.push(canvas);
      }

      // 2. Вверх (Up)
      {
        const { canvas, ctx } = this.makeCanvas(16, 24);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(8, 22, 5, 2, 0, 0, Math.PI*2);
        ctx.fill();

        // Шляпа сзади
        this.rect(ctx, 3, 2 + bobY, 10, 3, hatStraw);
        this.rect(ctx, 5, 0 + bobY, 6, 3, hatStraw);
        this.rect(ctx, 5, 2 + bobY, 6, 1, hatBand);

        // Волосы сзади
        this.rect(ctx, 5, 5 + bobY, 6, 4, '#5c381f');

        // Спина
        this.rect(ctx, 4, 9 + bobY, 8, 6, overallsBlue);
        this.rect(ctx, 5, 9 + bobY, 6, 1, shirtRed);
        this.rect(ctx, 6, 9 + bobY, 1, 5, overallsDark);
        this.rect(ctx, 9, 9 + bobY, 1, 5, overallsDark);

        // Ноги
        this.rect(ctx, 5, 15, 2, 4 + legOffset1, overallsDark);
        this.rect(ctx, 9, 15, 2, 4 + legOffset2, overallsDark);
        this.rect(ctx, 5, 19 + legOffset1, 2, 2, bootsBrown);
        this.rect(ctx, 9, 19 + legOffset2, 2, 2, bootsBrown);

        this.sprites.hero.up.push(canvas);
      }

      // 3. Вправо (Right)
      {
        const { canvas, ctx } = this.makeCanvas(16, 24);
        ctx.fillStyle = 'rgba(0,0,0,0.35)';
        ctx.beginPath();
        ctx.ellipse(8, 22, 5, 2, 0, 0, Math.PI*2);
        ctx.fill();

        // Шляпа в профиль
        this.rect(ctx, 3, 2 + bobY, 10, 3, hatStraw);
        this.rect(ctx, 5, 0 + bobY, 6, 3, hatStraw);
        this.rect(ctx, 5, 2 + bobY, 5, 1, hatBand);

        // Лицо в профиль
        this.rect(ctx, 6, 5 + bobY, 5, 4, skinColor);
        this.px(ctx, 10, 6 + bobY, '#2c3e50'); // Глаз
        this.px(ctx, 11, 7 + bobY, skinDark);  // Нос
        this.rect(ctx, 4, 5 + bobY, 3, 4, '#5c381f'); // Волосы сзади

        // Тело в профиль
        this.rect(ctx, 5, 9 + bobY, 6, 6, overallsBlue);
        this.rect(ctx, 6, 9 + bobY, 1, 5, overallsDark); // Лямка
        // Рука (машет при ходьбе)
        const armX = 7 + (f === 1 ? -1 : (f === 3 ? 1 : 0));
        this.rect(ctx, armX, 10 + bobY, 2, 4, skinColor);

        // Ноги в профиль
        this.rect(ctx, 6 + legOffset1, 15, 2, 4, overallsDark);
        this.rect(ctx, 7 + legOffset2, 15, 2, 4, overallsDark);
        this.rect(ctx, 6 + legOffset1, 19, 3, 2, bootsBrown);
        this.rect(ctx, 7 + legOffset2, 19, 3, 2, bootsBrown);

        this.sprites.hero.right.push(canvas);
      }

      // 4. Влево (Left) - отзеркаленный Right
      {
        const { canvas, ctx } = this.makeCanvas(16, 24);
        ctx.save();
        ctx.translate(16, 0);
        ctx.scale(-1, 1);
        ctx.drawImage(this.sprites.hero.right[f], 0, 0);
        ctx.restore();
        this.sprites.hero.left.push(canvas);
      }
    }
  },

  /* ------------------- ДЕКОРАЦИИ: ЗАБОР, ФОНАРНЫЙ СТОЛБ, КАМНИ ------------------- */
  createDecorations() {
    // 1. Деревянный заборчик (16x16)
    const fence = this.makeCanvas(16, 16);
    this.rect(fence.ctx, 2, 4, 3, 11, this.palette.woodDark);
    this.rect(fence.ctx, 11, 4, 3, 11, this.palette.woodDark);
    this.rect(fence.ctx, 2, 6, 12, 2, this.palette.woodMid);
    this.rect(fence.ctx, 2, 11, 12, 2, this.palette.woodMid);
    this.px(fence.ctx, 3, 3, this.palette.woodHighlight);
    this.px(fence.ctx, 12, 3, this.palette.woodHighlight);
    this.sprites.fence = fence.canvas;

    // 2. Фонарный столб с масляным фонарем (16x24)
    const lampPost = this.makeCanvas(16, 24);
    // Столб
    this.rect(lampPost.ctx, 7, 6, 2, 16, this.palette.woodDark);
    this.rect(lampPost.ctx, 5, 21, 6, 2, this.palette.stoneDark);
    // Перекладина
    this.rect(lampPost.ctx, 7, 5, 5, 2, this.palette.woodDark);
    // Подвесной металлический фонарь
    this.rect(lampPost.ctx, 10, 7, 4, 5, '#1e1f26');
    this.rect(lampPost.ctx, 11, 8, 2, 3, this.palette.goldBright); // Свет внутри
    this.sprites.lampPost = lampPost.canvas;

    // 3. Камушек (16x16)
    const rock = this.makeCanvas(16, 16);
    rock.ctx.fillStyle = 'rgba(0,0,0,0.3)';
    rock.ctx.fillRect(4, 13, 8, 2);
    this.rect(rock.ctx, 4, 8, 8, 5, this.palette.stoneDark);
    this.rect(rock.ctx, 5, 7, 6, 5, this.palette.stoneMid);
    this.rect(rock.ctx, 6, 7, 3, 2, this.palette.stoneLight);
    this.sprites.rock = rock.canvas;
  }
};
